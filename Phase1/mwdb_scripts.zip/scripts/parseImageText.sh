####################################################################
## This script creates json file from text descriptor files which ##
## can be uploaded to MongoDB.                                    ##
####################################################################

echo "Parsing image text descriptor file to make it uploadable to DB"

############# MAIN #############

USERFILE_ORIG=$1
#Declare variables
SOURCE="${PWD}"
echo $SOURCE
USERFILE="${SOURCE}/temp_textTermsPerImage.txt"
USERFILE_PARSED="${SOURCE}/parsed_textTermsPerImage.json"

#Empty temp files if already present
> ${USERFILE_PARSED}
> ${USERFILE}

TOTAL_USER=`cat ${USERFILE_ORIG} | wc -l`
echo "Total Users are : ${TOTAL_USER}" 

#remove double quotes from file
sed 's/"//g' ${USERFILE_ORIG} > ${USERFILE}

#Read file line by line
while read line
do
	#USERID=`cut -d" " -f1 $line`
	USERID=`echo $line| cut -f1 -d" "`
	ROW="{\"IMAGE_ID\":\"${USERID}\",\"TEXT_DESC\":["
	count=0
	
	# Skip userID while reading line from file as it is already taken inside variable USERID
	line=`echo $line | awk '{$1="";print $0}'`

	# Read line word by word
	for word in $line
	do
		#If count =0, it is TERM
		if [ ${count} -eq 0 ] 
		then
			ROW="${ROW}{\"TERM\": \"${word}\","
			count=`expr "${count}" + 1`
			#echo ${ROW}
		elif [ ${count} -eq 1 ]
		then
			ROW="${ROW}\"TF\":${word},"
			count=`expr "${count}" + 1`
		elif [ ${count} -eq 2 ]
		then
			ROW="${ROW}\"DF\":${word},"
			count=`expr "${count}" + 1`
		else
			count=0
			ROW="${ROW}\"TF_IDF\":${word}},"
			#echo ${ROW} >> ${USERFILE_PARSED}
			#echo ${ROW}
			#ROW="${USERID}"
		fi
	done
	# Trim last comma from string
	ROW=`echo "${ROW}" | sed 's/,$//'`
	echo "${ROW}]}" >> ${USERFILE_PARSED}
done < ${USERFILE}

#Remove temp files
rm -rf ${USERFILE} 
