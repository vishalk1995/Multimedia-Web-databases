import sys
import argparse
import xml.etree.ElementTree as ET
from pymongo import MongoClient

if __name__ == '__main__':
    parser = argparse.ArgumentParser('Add location info from topics file to mongoDB collection')
    parser.add_argument('--xml-file', type=str, required=True,
                        help='Path to xml file containing location information')
    parser.add_argument('--mongodb-hostname', type=str, default='localhost',
                        help='IP/hostname of mongodb server')
    parser.add_argument('--database', type=str, required=True,
                        help='Name of the MongoDB database')
    parser.add_argument('--collection', type=str, required=True,
                        help='Name of the collection to store location data')
    args = parser.parse_args()
    tree = ET.parse(args.xml_file)
    client = MongoClient(args.mongodb_hostname)
    collection = client.get_database(args.database).get_collection(args.collection)
    for child in tree.getroot():
        data = {}
        for location in child.getchildren():
            if location.tag == 'number':
                data[location.tag] = int(location.text)
            elif location.tag in ['longitude', 'latitude']:
                data[location.tag] = float(location.text)
            else:
                data[location.tag] = location.text
        collection.insert(data)
    sys.exit()
