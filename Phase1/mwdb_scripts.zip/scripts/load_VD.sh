#!/bin/bash
###############################################################################
## This script takes path to directory containing csv data and database name ##
## as input and loads it in the specified db                                 ##
###############################################################################

DATADIR=$1
DB=$2
COLLECTION=$3
VDS=(CM CM3x3 CN CN3x3 CSD GLRLM GLRLM3x3 HOG LBP LBP3x3)

for vd in $(echo ${VDS[*]})
do
  find $DATADIR -name "*$vd.csv" | while read file
  do
    echo "Loading data from $file in $COLLECTION collection of $DB database"
    location=`basename $file | cut -d ' ' -f 1`
    cat "$file" | while read line
    do
        image=`echo $line | cut -d ',' -f 1`
        desc=(${line//$image,/})
        location_object_id=`mongo ${DB} --eval="db.${COLLECTION}.findOne({\"location\": \"${location}\"})[\"_id\"]" | grep "ObjectId"`
        if [ -z "$location_object_id" ]
        then
            object="{\"location\": \"${location}\", \"${vd}\": [{\"image\": \"${image}\", \"scores\":[${desc}]}]}"
            mongo $DB --eval="db.$COLLECTION.insert(${object})" >> /dev/null
        else
            object="{${vd}: {\"image\": \"${image}\", \"scores\":[${desc}]}}"
            mongo $DB --eval="db.${COLLECTION}.update({\"_id\": ${location_object_id}}, {\$push: ${object}})" >> /dev/null
        fi
    done
  done
done
