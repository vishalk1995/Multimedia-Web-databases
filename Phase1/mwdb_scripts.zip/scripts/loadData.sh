#!/bin/bash
###############################################################################
## This script takes path to file containing json data as input and loads    ##
## it in the specified db and collection                                     ##
###############################################################################

DATAFILE=$1
DB=$2
COLLECTION=$3

echo "Loading data in $COLLECTION collection in $DB database"

while read line
do
  mongo $DB --eval "db.$COLLECTION.insert($line)" >> /dev/null
done < $DATAFILE
